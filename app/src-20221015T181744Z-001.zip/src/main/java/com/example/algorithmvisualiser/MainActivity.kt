package com.example.algorithmvisualiser

import AlgorithmEvents
import AlgorithmViewModel
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.MaterialTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
//import androidx.compose.ui.Alignment
import androidx.lifecycle.ViewModelProvider
import com.example.algorithmvisualiser.algorithms.InsertionSort
import com.example.algorithmvisualiser.ui.theme.AlgorithmVisualiserTheme
import com.example.algovis.components.VisualizerSection
import com.example.gamedevelpment.component.VisBottomBar



class MainActivity : ComponentActivity() {
    private val viewModel: AlgorithmViewModel by lazy {
        val viewModelProviderFactory = AlgorithmViewModelProvider(InsertionSort())
        ViewModelProvider(this, viewModelProviderFactory)[AlgorithmViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent{

            AlgorithmVisualiserTheme {

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colors.background)

                ){
                    Column {
                        VisualizerSection(
                            arr = viewModel.arr.value,
                            modifier = Modifier.fillMaxWidth()
                        )

                        val isPlaying = viewModel.isPlaying.value
                        val isFinished = viewModel.onSortingFinish.value
                        
                        VisBottomBar(
                            playPauseClick = {viewModel.onEvent(AlgorithmEvents.PlayPause) },
                            slowDownClick = { viewModel.onEvent(AlgorithmEvents.SlowDown)},
                            speedUpClick = { viewModel.onEvent(AlgorithmEvents.SpeedUp) },
                            previousClick = { viewModel.onEvent(AlgorithmEvents.Previous) },
                            nextClick = { viewModel.onEvent(AlgorithmEvents.Next)},
                                modifier = Modifier.fillMaxWidth()
                                .height(75.dp),
                            isPlaying = if(isFinished) !isFinished else isPlaying
                        )
                    }
                }
            }
        }
    }
}
